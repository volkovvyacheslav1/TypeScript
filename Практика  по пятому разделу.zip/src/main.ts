import './hanoi.ts';
import './genericContainer.ts';
