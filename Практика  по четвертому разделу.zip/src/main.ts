import './lesson_1.ts';
import './lesson_2.ts';

